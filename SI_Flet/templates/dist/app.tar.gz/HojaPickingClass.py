import SI_Resources as re
import flet as fl
import requests
from datetime import datetime

class Hoja_Picking(fl.Container):
    def __init__(self, page):
        super().__init__()
   
        self.expand = True
        self.cursor,self.cnxn = None, None
        self.result, self.description = None, None
        self.page = page

        self.HP_DataTable = fl.DataTable(
            col = 16,
            rows = [],
            column_spacing = 20,
            heading_row_height = 66,
            bgcolor = re.Colors().skyBG,
            vertical_lines=fl.BorderSide(0.2, "blue"),
            data_row_color = {fl.ControlState.HOVERED: "0x30FF0000"},
            heading_row_color = {fl.ControlState.DEFAULT: re.Colors().blueIntense},
            columns = [
                fl.DataColumn(fl.Text("Número Guía", color="white", col=1,size=14, text_align=fl.TextAlign.LEFT)),
                fl.DataColumn(fl.Text("Fecha de Generación", color="white", col=3, size=14, text_align=fl.TextAlign.CENTER)),
                fl.DataColumn(fl.Text("Estado Picking", color="white", col=2, size=14, text_align=fl.TextAlign.CENTER))
            ]
        )

        self.SI_ProgressRing_Container = fl.Container(
            opacity = 0.8,
            col=12,
            expand=True,
            margin = fl.margin.only(top=166),
            visible = False,
            bgcolor = "white",
            alignment=fl.alignment.center,
            content = fl.Column(
                width=40,
                height=40,
                controls = [fl.ProgressRing(
                    color="#153EC2", 
                    stroke_width=4,
                    width=40,
                    height=40
                )]
            )
        )

        self.page.overlay.append(self.SI_ProgressRing_Container)

        self.HP_Gallery = fl.Container(
            expand = True,
            content = fl.Column(
                expand = True, 
                scroll="Auto", 
                controls=[fl.ResponsiveRow([self.HP_DataTable], columns=6)]))


        self.HP_Body_Container = re.Containers([
            self.HP_Gallery  
        ]).body

        self.HP_Header_Container = fl.Container(  
            height = 86,
            content = fl.ResponsiveRow(
                expand = True,
                controls = [
                    re.Icons(lambda e:re.Functions(self.page).window_event(e.control)).exit_Icon,
                    re.Header_Title("Hoja Picking").title,
                    re.Header_Title("Bienvenido, <UserFullName>", lambda _:print("Bienvenida Clicked!")).bienvenida,
                    re.Icons(lambda _:self.load_data(None)).logo_Icon,
                ]
            ) ,
            bgcolor = "white",
            border_radius = 8,  
            shadow = re.Shadow().main
        )

        self.HP_Screen_Container = fl.SafeArea(fl.Column([self.HP_Header_Container, self.HP_Body_Container]))

        self.content = self.HP_Screen_Container  

    
    def connectSQL(self, sqlTable):
        init = datetime.now()
        query = 'http://192.168.2.134/' + sqlTable + '/?format=json'
        basic = ('user', 'client123')
        request = requests.get(query, auth=basic)
        print(request)
        result = request.json()
        print(result)
        fin = datetime.now()
        print("Tiempo de Conexión con API_REST:", fin - init)
        return result

    def fill_DataTable(self, result):
        init= datetime.now()
        self.HP_DataTable.rows.clear()
        self.append_DataTable(result)
        fin = datetime.now()
        print("Tiempo de LLenado de Tabla:",fin - init,"\n")

    def append_DataTable(self, result):
        for row in result['results']:
            self.HP_DataTable.rows.append(
                fl.DataRow(
                    data=row,
                    selected=False,
                    color={fl.ControlState.HOVERED: "0x30FF0000"},
                    on_select_changed=lambda e: re.Functions(self.page).HP_parse_Data(e, "/detalle_HP"),
                    cells=[
                        fl.DataCell(fl.Text(row['nro_guia'], color="#153EC2", col=1, size=12, text_align=fl.TextAlign.LEFT)),
                        fl.DataCell(fl.Text(row['fecha_atencion'], color="#153EC2", col=2, size=12, text_align=fl.TextAlign.CENTER)),
                        fl.DataCell(fl.Text(row['status_picking'], color="#153EC2", col=1, size=12, text_align=fl.TextAlign.LEFT))
                    ]
                )
            )

    def load_data(self, e):
        self.SI_ProgressRing_Container.visible = True
        if e is not None:
            print(f"loadData: {e.control.route}")
        self.page.update()
        self.result = self.connectSQL('Hoja_Picking')
        self.fill_DataTable(self.result)
        self.SI_ProgressRing_Container.visible = False
        self.page.update()
