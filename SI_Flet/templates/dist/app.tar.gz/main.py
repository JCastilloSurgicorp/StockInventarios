import flet as fl
import SI_Resources as re
from HojaPickingClass import Hoja_Picking
from DetalleHPClass import Detalle_HP


appName = "App Hoja Picking"

def main(page: fl.Page):
    page.title = appName
    page.bgcolor = "#F5F5F5"
    page.theme_mode = fl.ThemeMode.LIGHT
    page.window.prevent_close = True
    confirm_dialog = fl.AlertDialog(
        modal=True,
        title=fl.Text("Please confirm"),
        content=fl.Text("Do you really want to exit this app?"),
        actions=[
            fl.ElevatedButton("Yes", on_click=re.Functions(page).yes_click, bgcolor=fl.cupertino_colors.ACTIVE_GREEN),
            fl.OutlinedButton("No", on_click=re.Functions(page).no_click),
        ],
        actions_alignment=fl.MainAxisAlignment.END,
    )
    page.overlay.append(confirm_dialog)
    page.window.on_event = re.Functions(page).window_event

    HP = Hoja_Picking(page)
    
    DH = Detalle_HP(page)
    
    pages = {'/':fl.View("/",[HP]), '/detalle_HP':fl.View("/detalle_HP", [DH])}

    def route_change(e: fl.RouteChangeEvent):
        page.views.clear()
        page.views.append(pages[page.route])
        if page.route == '/detalle_HP':
            DH.__init__(page)
        if page.route == '/':
            page.update()
            if re.HP_Data.route != '/detalle_HP':
                HP.load_data(e)
        
    def view_pop(view):
        page.views.pop()
        print(f"view: {view}")
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)

if __name__ == "__main__":
    fl.app(target=main)
    