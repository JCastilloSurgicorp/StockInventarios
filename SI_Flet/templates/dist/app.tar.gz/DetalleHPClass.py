import flet as fl
import SI_Resources as re
import requests


class Detalle_HP(fl.Container):

    def __init__(self, page):
        super().__init__()
        
        self.expand = True
        
        self.page = page

        self.parse = re.HP_Data()

        
        query = fl.Text(self.parse.SelectedRecord['empr_id'])
        print(query)
        basic = ('user', 'client123')
        if query.value != '':
            empresa = requests.get(query.value, auth=basic).json()
            empresa = empresa['detail']
        else:
            empresa = ''
        
        self.DH_Form = fl.Column(
            spacing = 20,
            expand = True,
            scroll = fl.ScrollMode.AUTO,
            controls = [
                fl.ResponsiveRow(
                    controls = [
                        re.Card("Número de Guía", self.parse.SelectedRecord['nro_guia']).dataCard,
                        re.Card("OC Cliente", self.parse.SelectedRecord['oc_cliente']).dataCard,
                        re.Card("Estado de Picking", self.parse.SelectedRecord['status_picking']).dataCard
                    ]
                ),
                fl.ResponsiveRow(
                    controls = [
                        re.Card("Atención", self.parse.SelectedRecord['atencion']).dataCard,
                        re.Card("Firma de Atención", self.parse.SelectedRecord['firma_atencion']).dataCard,
                        re.Card("Fecha de Atención", self.parse.SelectedRecord['fecha_atencion']).dataCard,
                    ]
                ),
                fl.ResponsiveRow(
                    controls = [
                        re.Card("Almacén", self.parse.SelectedRecord['almacen']).dataCard,
                        re.Card("Firma de Almacén", self.parse.SelectedRecord['firma_almacen']).dataCard,
                        re.Card("Fecha de Almacén", self.parse.SelectedRecord['fecha_almacen']).dataCard,
                    ]
                ),
                fl.ResponsiveRow(
                    controls = [
                        re.Card("Distribución", self.parse.SelectedRecord['distribucion']).dataCard,
                        re.Card("Firma de Distribución", self.parse.SelectedRecord['firma_distribucion']).dataCard,
                        re.Card("Fecha de Distribución", self.parse.SelectedRecord['fecha_distribucion']).dataCard
                    ]
                ),
                fl.ResponsiveRow(
                    controls = [
                        re.Card("LIMA/PROVINCIA", self.parse.SelectedRecord['lima_provincia']).dataCard,
                        re.Card("Empresa", empresa).dataCard,
                        re.Card("url", "Empresa: " + self.parse.SelectedRecord['empr_id']).dataCard
                    ]   
                )
            ]
        )

        self.DH_Body_Container = fl.Container(
            expand = True,
            border_radius = 8,
            bgcolor = re.Colors().skyBG,
            shadow = re.Shadow().main,
            content = self.DH_Form
        )

        self.DH_Header_Container = fl.Container(  
            height = 86,
            content = fl.ResponsiveRow(
                expand = True,
                controls = [
                    re.Icons(lambda _:self.page.go("/")).back_Icon,
                    re.Header_Title(f"Detalle Hoja Picking {self.parse.SelectedRecord['nro_guia']}").title,
                    re.Header_Title("Bienvenido, <UserFullName>", lambda _:print("Bienvenida Clicked!")).bienvenida,
                    re.Icons(lambda _:print("Logo Clicked!")).logo_Icon
                ]
            ),
            bgcolor = "white",
            border_radius = 8,  
            shadow = re.Shadow().main
        )
        
        self.DH_Screen_Container = fl.SafeArea(content=fl.Column([self.DH_Header_Container, self.DH_Body_Container]))
        
        self.content = self.DH_Screen_Container
        self.page.update()



    def popView(self):
        self.page.go("/", True)
        print("into popView")